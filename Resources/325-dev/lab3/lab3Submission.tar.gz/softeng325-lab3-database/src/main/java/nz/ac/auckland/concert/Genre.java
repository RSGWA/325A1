package nz.ac.auckland.concert;

public enum Genre {
	Pop, HipHop, RhythmAndBlues, Acappella, Metal, Rock 
}

